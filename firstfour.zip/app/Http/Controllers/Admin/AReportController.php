<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
class AReportController extends Controller
{

          //Create a new branch
          public function viewReport(Request $request)
          {
            $userId=$request->input('id');
            $students=DB::table('students')->get();
            return view('Admin.Report',['students'=>$students]);
          }

}
