<?php

namespace App\Http\Controllers\Branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class AdmissionController extends Controller
{
  public function getStudentDetails()
  {

    $students = DB::table('students')->where('status','Applied')->get();
    $courses = DB::table('courses')->pluck('courseName','courseId')->toArray();
   return view('Branch.studentAdmission',['students' => $students,'courses' => $courses]);
  }
  //Get courses names
  public function getCoursesName()
  {

    $courses = DB::table('courses')->pluck('courseName','courseId')->toArray();

   return view('Branch.studentAdmission',['courses' => $courses]);


  }

  //Generate roll number
  public function rollNumber()
  {
    $rollNumber=DB::table('students')
                    ->max('rollNumber');
    $rollNumber=$rollNumber+1;
   return $rollNumber;


  }

    //Generate rgd number
    public function rgdNumber()
    {
      $rgdNumber=DB::table('students')
                      ->max('rgdNumber');
      $rgdNumber=$rgdNumber + 1;
       return $rgdNumber;


    }

      //Generate roll number
      public function certificateNo()
      {
      $certificateNo=DB::table('students')
                      ->max('certificateNo');
      $certificateNo=$certificateNo + 1;
       return $certificateNo;


      }


    //Add student
      public function newStudent(Request $request)
      {

      ///////////Input data validation//////


           $validatedData = $request->validate([
                  'name' => 'required',
                  'subjectName' => 'required',
                  'fname' => 'required',
                  'mname' => 'required',
                  'Address' => 'required',
                  'contactnumber' => 'required',
                  'courseId' => 'required',
                  'emailId' => 'required',
              ],
              [
               'name.required'=> 'Student Name is Required',
               'subjectName.required'=> 'Subject name is Required',
               'fname.required'=> 'Name of father of studentr is Required',
               'mname.required'=> 'Name of mother of studentr is Required',
               'Address.required'=> 'Address is Required',
               'contactnumber.required'=> 'Contact number is Required',
               'courseId.required'=> 'Course should be selected.',
               'emailId.required'=> 'Email Id is Required',
              ]
           );
       ///////////////////////////////////////////////
//////////////////////////////////////
        $studentid=$request->input('studentid');
        $courseId=$request->input('courseId');
        $email=$request->input('emailId');
        //$course=$request->input('course');
        $course=DB::table('courses')
                        ->select('courseName')
                        ->where('courseId',$courseId)
                        ->get();
        $rgdNumber=AdmissionController::rgdNumber();


        $rollNumber=AdmissionController::rollNumber();


        $certificateNo=AdmissionController::certificateNo();

        $name=$request->input('name');
        $affected = DB::table('students')
        ->where('studentId', $studentid)
        ->where('emailId',$email)
        ->update([
      'name' =>$name ,
      'fname' => $request->input('fname'),
      'mname' => $request->input('mname'),
      'Address' => $request->input('Address'),
      'cnumber' => $request->input('cnumber'),
      'course' => $course[0]->courseName,
      'courseId' => $courseId,
      'emailId' => $email,
      'rollNumber' => $rollNumber,
      'rgdNumber' => $rgdNumber,
      'status' => 'Student',
      'cMStatus' => $request->input('cMStatus'),
      'cPStatus' => $request->input('cPStatus'),
      'certificateNo' => $certificateNo
  ]);


  /*Search for duplicate and delete*/
  $duplicated = DB::table('students')
                      ->select('studentId')
                      ->where('emailId',$email)
                      ->where('courseId',$courseId)
                      ->first();

      $studentId=$duplicated->studentId;
      DB::table('students')->where('studentId', '!=', $studentId)->where('emailId',$email)->where('courseId',$courseId)->delete();


  /*Search for duplicate and delete*/
  return back()->with('success','Student Record Added.');
  //return ('Student Record Added.');
      }


}
