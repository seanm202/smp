<?php

namespace App\Http\Controllers\Branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    //Report Management
    public function manageReport()
    {
return back()->with("Report updated.");
    }
}
