<!DOCTYPE html>
<html>
<head>
    <title>Hi</title>
    <link rel="stylesheet" type="text/css" href="{{ asset('/css/Student/myPDF.css') }}" />

</head>
<body>

  <div class="heading">
    <h2>{{ $title }}</h2></div>
    <div class="date"><h3>{{ $date }}</h3></div>
      <div class="pCertificate">
        <div class="detdiv">
    <h3 class="details">Name : </h3><h3 class="ddetails">{{ $name }}</h3></div>
      <br>

      <div class="detdiv">
    <h3 class="details">Registration No: </h3><h3 class="ddetails">{{ $rgdNumber }}</h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Course Name: </h3><h3 class="ddetails">{{ $course }}</h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Father's Name: </h3><h3 class="ddetails">{{ $fname }}</h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Mother's Name: </h3><h3 class="ddetails">{{ $mname }}</h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Center Id : </h3><h3 class="ddetails">{{ $centerId }}</h3></div>
      <br>
      @if(isset($centerAddress))
      <div class="detdiv">
    <h3 class="details">Center Address: </h3><h3 class="ddetails">{{ $centerAddress }}</h3></div>
      <br>
      @endif
      <div class="detdiv">
    <h3 class="details">Start Date : </h3><h3 class="ddetails">{{ $startDate }}</h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">End Date : </h3><h3 class="ddetails">{{ $endDate }}</h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Grade : </h3><h3 class="ddetails">{{ $grade }}</h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Certificate No. : </h3><h3 class="ddetails">{{ $certificateNo }}</h3></div>
      <br>
      </div>
      <div class="signature">
      <div class="studentSignature"><img src="#" alt="StudentSignature"/><br><h3>Student Signature</h3></div>
      <div class="principalSignature"><img src="#" alt="Principal'sSignature"/><br><h3>Principal's Signature</h3></div>
    </div>
      </div>
      <div class="certDesc">
      <p><h4>This is to certify that Mr./Mrs.{{$name}} has completed the course {{$course}} and attained the grade - {{$grade}} after attending class for the same at our institution during the period {{$startDate}} to {{$endDate}}.We wish him the best for his future.</h4></p>
    </div>
</body>
</html
