<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<style>
.branchForm{
  display: flex;
  padding-left:20px;
}
.adminImage
{height: 30%;
padding-left:60px;
border-radius: 2px;
border: 5px solid black;
}
</style>

    </head>
    <body>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="dashboard">Go to dashboard</a></h3>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
      <h2>Add Branch</h2>
    <div class="branchForm">
      <?php $__currentLoopData = $branchDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branchdet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="adminDetails">
      <?php echo e(Form::open(array('route' => 'addBranch','method'=>'post'))); ?>

      <?php echo e(Form::label('owner name', 'Branch name :')); ?>

      <?php echo e(Form::text('branchName',$branchdet->branchName)); ?><br><br>
      <?php echo e(Form::label('owner name', 'Branch head name :')); ?>

      <?php echo e(Form::text('branchheadName',$branchdet->name)); ?><br><br>
      <?php echo e(Form::label('cnumber', 'Contact Number :')); ?>

      <?php echo e(Form::number('cnumber')); ?><br><br>
      <?php echo e(Form::label('email', 'Branch Email Id :')); ?>

      <?php echo e(Form::email('branchemail',$branchdet->mailId)); ?><br><br>
      <?php echo e(Form::label('branchId', 'BranchId :')); ?>

      <?php echo e(Form::number('branchId',$branchdet->branchId)); ?><br><br>
      <?php echo e(Form::label('branchAddress', 'Branch Address :')); ?>

      <?php echo e(Form::text('branchAddress')); ?><br><br>
      <?php echo e(Form::submit('Add')); ?><br><br>
      <?php echo e(Form::close()); ?>


      <?php echo e(Form::open(array('method' => 'put','route' => 'provideAdminImage','files' => 'true','enctype'=>'multipart/form-data'))); ?>

      <?php echo e(Form::token()); ?>

      <?php echo e(Form::label('file', 'Add Photo')); ?><br>
      <?php echo e(Form::file('file')); ?><br><br>
      <?php echo e(Form::hidden('branchId',$branchdet->branchId)); ?><br>
      <?php echo e(Form::submit('Upload')); ?><br>
            <?php echo e(Form::close()); ?>

          </div>
            <div class="adminImage">
              <img src="" alt="<?php echo e($branchdet->name); ?>"/>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <div class="viewBranch">


    </div>
    <hr>
    <div>
      <h2>Suspend Branch</h2>
      <?php echo e(Form::open(array('route' => 'suspendBranch'))); ?>

      <?php echo e(Form::select('id', $branch)); ?>

      <?php echo e(Form::submit('Suspend')); ?>

    <?php echo e(Form::close()); ?>

    </div>
    <hr>
    <div class="reactivateBranch">
      <h2>Reactivate Branch</h2>
      <?php echo e(Form::open(array('route' => 'reactivateBranch'))); ?>

      <?php echo e(Form::select('id', $branch)); ?>

      <?php echo e(Form::submit('Reactivate')); ?>

    <?php echo e(Form::close()); ?>

    </div>
    <hr>
    <div class="deleteBranch">
      <h2>Delete Branch</h2>
      <?php echo e(Form::open(array('route' => 'deleteBranch'))); ?>

      <?php echo e(Form::select('id', $branch)); ?>

      <?php echo e(Form::submit('Delete')); ?>

    <?php echo e(Form::close()); ?>

    </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMPLL\resources\views/Admin/Branch/crudBranch.blade.php ENDPATH**/ ?>