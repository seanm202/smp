<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">


    </head>
    <body>
      <h2>Create/Read/Edit/Delete Course(s)</h2>
      <div class="addBranch">
        <h2>Add Course(s)</h2>
        <?php echo e(Form::open(array('route' => 'addCourse','method'=>'post'))); ?>

        <?php echo e(Form::label('courseid', 'Course Id :')); ?>

        <?php echo e(Form::text('courseId')); ?><br><br>
        <?php echo e(Form::label('course', 'Course Name :')); ?>

        <?php echo e(Form::text('courseName')); ?>

        <?php echo e(Form::submit('Add')); ?>

      <?php echo e(Form::close()); ?>

      </div>
      <hr>
      <div class="deleteCourse">
        <h2>Delete Course(s)</h2>
        <?php echo e(Form::open(array('route' => 'deleteCourse'))); ?>

        <?php echo e(Form::select('courseId',$courses)); ?>

        <?php echo e(Form::hidden('id')); ?>

        <?php echo e(Form::submit('Delete')); ?>

      <?php echo e(Form::close()); ?>

      </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Admin/crudCourse.blade.php ENDPATH**/ ?>