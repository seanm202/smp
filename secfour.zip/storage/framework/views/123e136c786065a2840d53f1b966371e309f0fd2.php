<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

<!--Styles -->
<!--<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Student/dashboard.css')); ?>" />-->
    </head>
    <body>
<h2>Your account is not yet activated.</h2>
<h2><a href="logout">Logout</a></h2>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
<div class="appliedFor">
  <h3>Please select the desired role</h3>
  <p>
  <?php echo e(Form::open(array('route' => 'appliedFor','method'=>'post'))); ?>

  <?php echo e(Form::label('role', 'Role :')); ?>

  <?php echo e(Form::select('roleId',$roles)); ?>

  <?php echo e(Form::hidden('applicantId',$userId)); ?>

  <?php echo e(Form::submit('Submit')); ?>

<?php echo e(Form::close()); ?>

</p>
</div>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMPLL\resources\views/Guest/guestdashboard.blade.php ENDPATH**/ ?>