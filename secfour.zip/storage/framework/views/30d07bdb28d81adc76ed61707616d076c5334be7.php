<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

                <!--Styles -->
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Admin/assignRoles.css')); ?>" />
<style>
#accounts {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#accounts td, #accounts th {
  border: 1px solid #ddd;
  padding: 8px;
}

#accounts tr:nth-child(even){background-color: #f2f2f2;}

#accounts tr:hover {background-color: #ddd;}

#accounts th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.buttonDelete {
  background-color: red;
  border: none;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
    </head>
    <body>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="dashboard">Go to dashboard</a></h3>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
      <h2>Approve accounts</h2>
      <div class="assignRole">
        <table id="accounts">
            <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Applied for</th>
            <th>Approve as</th>
            <th>Delete</th>
            </tr>
            <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($applicant->name); ?></td>
            <td><?php echo e($applicant->email); ?></td>
            <td><?php echo e($applicant->appliedAs); ?></td>
            <td> <?php echo e(Form::open(array('route' => 'assignRole','method'=>'post'))); ?>

        <?php echo e(Form::label('role', 'Role :')); ?>

        <?php echo e(Form::select('roleId',$roles)); ?><br><br>
        <?php echo e(Form::hidden('id',$applicant->id)); ?>

        <?php echo e(Form::hidden('userName',$applicant->name)); ?>

        <?php echo e(Form::hidden('userEmail',$applicant->email)); ?>

        <?php echo e(Form::submit('Accept/Assign Role', array('class' =>'button'))); ?>

      <?php echo e(Form::close()); ?></td>
      <td><?php echo e(Form::open(array('route' => 'deleteApplicant','method'=>'post','class' => 'buttonDelete'))); ?>

  <?php echo e(Form::hidden('id',$applicant->id)); ?>

  <?php echo e(Form::submit('Delete', array('class' =>'button'))); ?>

<?php echo e(Form::close()); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMPLL\resources\views/Admin/assignRoles.blade.php ENDPATH**/ ?>