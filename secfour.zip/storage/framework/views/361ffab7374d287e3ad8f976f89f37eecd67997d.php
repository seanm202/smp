<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">


    </head>
    <body>
      <h2>Branch Dashboard</h2>
      <h3>Welcome</h3>
        <h3><a href="logout">Logout</a></h3>
          <h3><a href="addStudent">Add student</a></h3>
            <h3><a href="branchExamManagement">Manage Exam</a></h3>
              <h3><a href="genReport">Generate Report</a></h3>
      <div class="branchOwnerDetails">
        <?php $__currentLoopData = $branchOwner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
          <img src="<?php echo e($bow->image); ?>" alt="<?php echo e($bow->name); ?>"/>
        </div>
      <h3>Name: <?php echo e($bow->name); ?></h3>
      <h3>Contact Number: <?php echo e($bow->cnumber); ?></h3>
      <h3>Mail Id: <?php echo e($bow->mailId); ?></h3>
      <h3>Branch Id: <?php echo e($bow->branchId); ?></h3>
      <h3>Address: <?php echo e($bow->address); ?></h3>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!--
    <div class="updatePassword">
      <h2>Change password</h2>
      <?php echo e(Form::open(array('action' => 'LoginController@updatePassword','method'=>'post'))); ?>

      <?php echo e(Form::label('password', 'New Password')); ?>

      <?php echo e(Form::password('password')); ?>

      <?php echo e(Form::submit('Update')); ?>

    <?php echo e(Form::close()); ?>

  </div>
-->
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Branch/branchDashboard.blade.php ENDPATH**/ ?>