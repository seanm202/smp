<!DOCTYPE html>
<html>
<head>
    <title>Hi</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Student/myPDF.css')); ?>" />

</head>
<body>

  <div class="heading">
    <h2><?php echo e($title); ?></h2></div>
    <div class="date"><h3><?php echo e($date); ?></h3></div>
      <div class="pCertificate">
        <div class="detdiv">
    <h3 class="details">Name : </h3><h3 class="ddetails"><?php echo e($name); ?></h3></div>
      <br>

      <div class="detdiv">
    <h3 class="details">Registration No: </h3><h3 class="ddetails"><?php echo e($rgdNumber); ?></h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Course Name: </h3><h3 class="ddetails"><?php echo e($course); ?></h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Father's Name: </h3><h3 class="ddetails"><?php echo e($fname); ?></h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Mother's Name: </h3><h3 class="ddetails"><?php echo e($mname); ?></h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Center Id : </h3><h3 class="ddetails"><?php echo e($centerId); ?></h3></div>
      <br>
      <?php if(isset($centerAddress)): ?>
      <div class="detdiv">
    <h3 class="details">Center Address: </h3><h3 class="ddetails"><?php echo e($centerAddress); ?></h3></div>
      <br>
      <?php endif; ?>
      <div class="detdiv">
    <h3 class="details">Start Date : </h3><h3 class="ddetails"><?php echo e($startDate); ?></h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">End Date : </h3><h3 class="ddetails"><?php echo e($endDate); ?></h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Grade : </h3><h3 class="ddetails"><?php echo e($grade); ?></h3></div>
      <br>
      <div class="detdiv">
    <h3 class="details">Certificate No. : </h3><h3 class="ddetails"><?php echo e($certificateNo); ?></h3></div>
      <br>
      </div>
      <div class="signature">
      <div class="studentSignature"><img src="#" alt="StudentSignature"/><br><h3>Student Signature</h3></div>
      <div class="principalSignature"><img src="#" alt="Principal'sSignature"/><br><h3>Principal's Signature</h3></div>
    </div>
      </div>
      <div class="certDesc">
      <p><h4>This is to certify that Mr./Mrs.<?php echo e($name); ?> has completed the course <?php echo e($course); ?> and attained the grade - <?php echo e($grade); ?> after attending class for the same at our institution during the period <?php echo e($startDate); ?> to <?php echo e($endDate); ?>.We wish him the best for his future.</h4></p>
    </div>
</body>
</html
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Student\myPDF.blade.php ENDPATH**/ ?>