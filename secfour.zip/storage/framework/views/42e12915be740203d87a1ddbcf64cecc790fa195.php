<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

<!--Styles -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Student/dashboard.css')); ?>" />
    </head>
    <body>
      <div class="All">
      <div class="start">
      <h2>Welcome</h2>
      <h3>Student Profile Page</h3>
    </div>
      <div id="app" style="color:red;background-color:grey;">
       <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


       <?php echo $__env->yieldContent('content'); ?>
   </div>
      <hr>
      <div class="Attr">
      <div class="leftsAttributes">
      <div class="log">
        <h3><a href="logout">Logout</a></h3>
      </div>
      <div class="stuDownload">
        <h3><a href="viewPro">View provisional Certificate</a></h3>
        <h3><a href="viewMark">View MarkSheet Certificate</a></h3>
        <h3><a href="downloadPro">Download provisional Certificate</a></h3>
        <h3><a href="downloadMark">Download MarkSheet Certificate</a></h3>
      </div>
    </div>
      <div class="studentPofile">
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="sideLine">
<div class="vl"></div><h3 style="padding-right:200px;">Name : <?php echo e($student->name); ?></h3><div class="imagePos"><img src="<?php echo e($student->Image); ?>"/></div>
</div>
        <hr>
        <br>
<div class="sideLine">
<div class="vl"></div><h3>Roll Number : <?php echo e($student->rollNumber); ?></h3>
</div>
        <hr>
        <br>
<div class="sideLine">
<div class="vl"></div><h3>Registration Number : <?php echo e($student->rgdNumber); ?></h3>
</div>
        <hr>
        <br>
<div class="sideLine">
<div class="vl"></div><h3>Address : <?php echo e($student->Address); ?></h3>
</div>
        <hr>
        <br>
<div class="sideLine">
<div class="vl"></div><h3>Course(s) List : <?php echo e($student->course); ?></h3>
</div>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Student/studentDashboard.blade.php ENDPATH**/ ?>