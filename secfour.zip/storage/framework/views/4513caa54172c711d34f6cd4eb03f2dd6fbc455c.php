<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <style>
        .eachStudent{
          border: black solid 20px;
        }
        </style>
    </head>
    <body>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="Admin/adminDashboard">Go to dashboard</a></h3>
      <h2>Create/Read/Edit/Delete Student('s) details</h2>
      <div>
              <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="eachStudent">
              <?php echo e(Form::open(array('route' => 'admitStudent'))); ?>

              <?php echo e(Form::token()); ?>

              <?php echo e(Form::hidden('id', $student->studentId)); ?>

              <?php echo e(Form::hidden('name',$student->name)); ?>

              <table>
                <tr><td>Name :</td><td><?php echo e($student->name); ?></td></tr>
                  <tr><td>Photo :</td><td><img src="<?php echo e($student->Image); ?>"/></td></tr>
                <tr><td>Father's Name :</td><td><?php echo e($student->fname); ?></td></tr>
                <tr><td>Mother's Name :</td><td><?php echo e($student->mname); ?></td></tr>
                <tr><td>Address :</td><td><?php echo e($student->Address); ?></td></tr>
                <tr><td>Contact No. :</td><td><?php echo e($student->cnumber); ?></td></tr>
                <tr><td>Mail Id :</td><td><?php echo e($student->emailId); ?></td></tr>
                <tr><td>Name of the course :</td><td><?php echo e($student->course); ?></td></tr>
                <tr><td>Registration Number :</td><td><?php echo e($student->rgdNumber); ?></td></tr>
                <tr><td>Roll Number :</td><td><?php echo e($student->rollNumber); ?></td></tr>
              </table>
              <hr>
              <table>
                <tr>
                  <th>Qualification</th>
                  <th>Board/University</th>
                  <th>Full Mark</th>
                  <th>Secured Mark</th>
                </tr>
                <tr>
                  <td>10th</td>
                  <td><?php echo e($student->tBUniv); ?></td>
                  <td><?php echo e($student->tTotalMark); ?></td>
                  <td><?php echo e($student->tMark); ?></td>
                </tr>
                <tr>
                  <td>12th</td>
                  <td><?php echo e($student->twBUniv); ?></td>
                  <td><?php echo e($student->twTotalMark); ?></td>
                  <td><?php echo e($student->twMark); ?></td>
                </tr>
                <tr>
                  <td>13th</td>
                  <td><?php echo e($student->thBUniv); ?></td>
                  <td><?php echo e($student->thTotalMark); ?></td>
                  <td><?php echo e($student->thMark); ?></td>
                </tr>
                <tr>
                  <td>Other</td>
                  <td><?php echo e($student->otherBUniv); ?></td>
                  <td><?php echo e($student->otherTotalMark); ?></td>
                  <td><?php echo e($student->otherMark); ?></td>
                </tr>
              </table>
              <?php echo e(Form::submit('Continue', array('name' => 'status'))); ?>

              <?php echo e(Form::submit('Discontinue', array('name' => 'status'))); ?>

              <?php echo e(Form::submit('Completed', array('name' => 'status'))); ?>

              <?php echo e(Form::submit('Terminated', array('name' => 'status'))); ?>

                    <?php echo e(Form::close()); ?>

                    <hr>
                    <?php echo e(Form::open(array('route' => 'provideProvisionalCertificate'))); ?>

                    <?php echo e(Form::token()); ?>

                    <?php echo e(Form::hidden('id', $student->studentId)); ?>

                    <?php echo e(Form::hidden('name',$student->name)); ?>

                    <?php echo e(Form::label('provCertificate','Issue Provisional Certificate :')); ?>

                    <?php echo e(Form::submit('Issue')); ?>

                    <hr>
                    <?php echo e(Form::close()); ?>

                    <?php echo e(Form::open(array('route' => 'provideMarkSheetCertificate'))); ?>

                    <?php echo e(Form::token()); ?>

                    <?php echo e(Form::hidden('id', $student->studentId)); ?>

                    <?php echo e(Form::hidden('name',$student->name)); ?>

                    <?php echo e(Form::label('markCertificate','Issue Marksheet Certificate :')); ?>

                    <?php echo e(Form::submit('Issue')); ?>

                    <?php echo e(Form::close()); ?>

                    <hr>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Admin/makeAuthorize.blade.php ENDPATH**/ ?>