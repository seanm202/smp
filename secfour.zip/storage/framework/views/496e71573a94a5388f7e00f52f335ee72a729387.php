<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!--Styles -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Admin/adminDashboard.css')); ?>" />

    </head>
    <body>
      <h2>Admin Dashboard</h2>
      <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h3>Welcome <?php echo e($ad->name); ?></h3>
      <h3>Email Id :<?php echo e($ad->emailId); ?></h3>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div id="app">
              <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


              <?php echo $__env->yieldContent('content'); ?>
          </div>
          <!-- Scripts -->
          <script src="/js/app.js"></script>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="getRoles">Assign role to the new aplicants</a></h3>
        <h3><a href="authorizeCertificate">Authorize Certificate</a></h3>
        <h3><a href="AdminBranch">Add/Update branches</a></h3>
        <h3><a href="AdminCourse">Add/Update Courses</a></h3>
        <h3><a href="AdminSubject">Add/Update Subjects</a></h3>
        <h3><a href="AdminReport">Check Report</a></h3>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMPLL\resources\views/Admin/adminDashboard.blade.php ENDPATH**/ ?>