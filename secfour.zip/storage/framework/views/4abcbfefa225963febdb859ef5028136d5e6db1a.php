<?php echo e($slot); ?>

<?php /**PATH /home/u548630683/domains/jsttryngnout.tech/SMP/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>