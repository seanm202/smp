<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">


    </head>
    <body>
      <h2>Admin Dashboard</h2>
      <h3>Welcome</h3>

        <h3><a href="logout">Logout</a></h3>
        <h3><a href="getRoles">Assign role to the new aplicants</a></h3>
        <h3><a href="authorizeCertificate">Authorize Certificate</a></h3>
        <h3><a href="AdminBranch">Add/Update branches</a></h3>
        <h3><a href="AdminCourse">Add/Update Courses</a></h3>
        <h3><a href="AdminSubject">Add/Update Subjects</a></h3>
        <h3><a href="AdminReport">Check Report</a></h3>
    </body>
</html>
<?php /**PATH /home/u548630683/domains/jsttryngnout.tech/SMP/resources/views/Admin/adminDashboard.blade.php ENDPATH**/ ?>