<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">


    </head>
    <body>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="Admin/adminDashboard">Go to dashboard</a></h3>
      <h2>Approve accounts(s)</h2>
      <div class="assignRole">
        <table>
            <tr>
            <th>Name :</th>  
            <th>Email :</th>
            <th>Approve as</th> 
            </tr>
            <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($applicant->name); ?></td>
            <td><?php echo e($applicant->email); ?></td>
            <td> <?php echo e(Form::open(array('route' => 'assignRole','method'=>'post'))); ?>

        <?php echo e(Form::label('role', 'Role :')); ?>

        <?php echo e(Form::select('roleId',$roles)); ?><br><br>
        <?php echo e(Form::hidden('id',$applicant->id)); ?>

        <?php echo e(Form::hidden('userName',$applicant->name)); ?>

        <?php echo e(Form::hidden('userEmail',$applicant->email)); ?>

        <?php echo e(Form::submit('Accept/Assign Role')); ?>

      <?php echo e(Form::close()); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Admin/assignRoles.blade.php ENDPATH**/ ?>