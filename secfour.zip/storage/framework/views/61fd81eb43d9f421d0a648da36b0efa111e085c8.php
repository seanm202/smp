<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <style>
        .eachStudent{
          padding: 20px;
          border: black solid 20px;
        }

                .thePhoto
                {
                  display: flex;
                }
                .withPhoto
                {
                padding-left: 120px;
                }
                .havingPhoto
                {
                padding-right: 120px;
                }
        .issueButton
        {
          display: flex;
        }
        .qualification
        {
        padding-left: 120px;
        }
        .certificateIssue
        {
        padding-right: 50px;
        }


        #accounts {
          font-family: Arial, Helvetica, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }

        #accounts td, #accounts th {
          border: 1px solid #ddd;
          padding: 8px;
        }

        #accounts tr:nth-child(even){background-color: #f2f2f2;}

        #accounts tr:hover {background-color: #ddd;}

        #accounts th {
          padding-top: 12px;
          padding-bottom: 12px;
          text-align: left;
          background-color: #04AA6D;
          color: white;
        }


.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.buttonTerm {
  background-color: red;
  border: none;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.buttonComp {
  background-color: blue;
  border: none;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.buttonDis {
  background-color: brown;
  border: none;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
        </style>
    </head>
    <body>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="dashboard">Go to dashboard</a></h3>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
      <h2>Create/Read/Edit/Delete Student('s) details</h2>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="eachStudent">
                <div class="thePhoto">
                  <div class="withPhoto">
              <?php echo e(Form::open(array('route' => 'admitStudent'))); ?>

              <?php echo e(Form::token()); ?>

              <?php echo e(Form::hidden('id', $student->studentId)); ?>

              <?php echo e(Form::hidden('name',$student->name)); ?>

              <table>
                <tr><td>Name :</td><td><?php echo e($student->name); ?></td></tr>
                <tr><td>Father's Name :</td><td><?php echo e($student->fname); ?></td></tr>
                <tr><td>Mother's Name :</td><td><?php echo e($student->mname); ?></td></tr>
                <tr><td>Address :</td><td><?php echo e($student->Address); ?></td></tr>
                <tr><td>Contact No. :</td><td><?php echo e($student->cnumber); ?></td></tr>
                <tr><td>Mail Id :</td><td><?php echo e($student->emailId); ?></td></tr>
                <tr><td>Name of the course :</td><td><?php echo e($student->course); ?></td></tr>
                <tr><td>Registration Number :</td><td><?php echo e($student->rgdNumber); ?></td></tr>
                <tr><td>Roll Number :</td><td><?php echo e($student->rollNumber); ?></td></tr>
              </table>
            </div>
              <div class="havingPhoto">
                <img src="<?php echo e($student->Image); ?>"/>
              </div>
            </div>
              <hr>
              <div class="issueButton">
              <div class="qualification">
              <table id="accounts">
                <tr>
                  <th>Qualification</th>
                  <th>Board/University</th>
                  <th>Full Mark</th>
                  <th>Secured Mark</th>
                </tr>
                <tr>
                  <td>10th</td>
                  <td><?php echo e($student->tBUniv); ?></td>
                  <td><?php echo e($student->tTotalMark); ?></td>
                  <td><?php echo e($student->tMark); ?></td>
                </tr>
                <tr>
                  <td>12th</td>
                  <td><?php echo e($student->twBUniv); ?></td>
                  <td><?php echo e($student->twTotalMark); ?></td>
                  <td><?php echo e($student->twMark); ?></td>
                </tr>
                <tr>
                  <td>13th</td>
                  <td><?php echo e($student->thBUniv); ?></td>
                  <td><?php echo e($student->thTotalMark); ?></td>
                  <td><?php echo e($student->thMark); ?></td>
                </tr>
                <tr>
                  <td>Other</td>
                  <td><?php echo e($student->otherBUniv); ?></td>
                  <td><?php echo e($student->otherTotalMark); ?></td>
                  <td><?php echo e($student->otherMark); ?></td>
                </tr>
              </table>
              <?php echo e(Form::submit('Continue', array('name' => 'status','class' =>'button'))); ?>

              <?php echo e(Form::submit('Discontinue', array('name' => 'status','class' =>'buttonDis'))); ?>

              <?php echo e(Form::submit('Completed', array('name' => 'status','class' =>'buttonComp'))); ?>

              <?php echo e(Form::submit('Terminate', array('name' => 'status','class' =>'buttonTerm'))); ?>

                    <?php echo e(Form::close()); ?>

                  </div>
                    <hr>
                    <div class="certificateIssue">
                    <?php echo e(Form::open(array('route' => 'provideProvisionalCertificate'))); ?>

                    <?php echo e(Form::token()); ?>

                    <?php echo e(Form::hidden('id', $student->studentId)); ?>

                    <?php echo e(Form::hidden('name',$student->name)); ?>

                    <?php echo e(Form::label('provCertificate','Issue Provisional Certificate :')); ?>

                    <?php echo e(Form::submit('Issue', array('class' =>'button'))); ?>

                    <hr>
                    <?php echo e(Form::close()); ?>

                    <?php echo e(Form::open(array('route' => 'provideMarkSheetCertificate'))); ?>

                    <?php echo e(Form::token()); ?>

                    <?php echo e(Form::hidden('id', $student->studentId)); ?>

                    <?php echo e(Form::hidden('name',$student->name)); ?>

                    <?php echo e(Form::label('markCertificate','Issue Marksheet Certificate :')); ?>

                    <?php echo e(Form::submit('Issue', array('class' =>'button'))); ?>

                    <?php echo e(Form::close()); ?>

                    <hr>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMPLL\resources\views/Admin/makeAuthorize.blade.php ENDPATH**/ ?>