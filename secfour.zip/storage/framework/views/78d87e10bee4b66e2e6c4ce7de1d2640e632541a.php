<!DOCTYPE html>
<html>
<head>
    <title>Hi</title>
</head>
<body>
    <p><?php echo e($title); ?></p>
    <p><?php echo e($date); ?></p>
    <p><?php echo e($name); ?></p>
    <p><?php echo e($rgdNumber); ?></p>
    <p><?php echo e($rollNumber); ?></p>
    <p><?php echo e($course); ?></p>
    <p><?php echo e($fname); ?></p>
    <p><?php echo e($mname); ?></p>
    <p><?php echo e($image); ?></p>
    <p><?php echo e($centerId); ?></p>
    <?php if(isset($centerAddress)): ?>
    <p>Center Address : <?php echo e($centerAddress); ?></p>
    <?php endif; ?><p><?php echo e($startDate); ?></p>
    <p><?php echo e($endDate); ?></p>
    <p><?php echo e($grade); ?></p>
    <p><?php echo e($certificateNo); ?></p>
</body>
</html
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Student/myPDF.blade.php ENDPATH**/ ?>