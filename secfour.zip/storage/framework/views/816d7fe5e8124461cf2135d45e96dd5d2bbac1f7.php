<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Student/markSheetCertificate.css')); ?>" />

    </head>
    <body>
      <h2>Marksheet Certificate</h2>
      <div class="mCertificate">
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3>Roll No: <?php echo e($student->rollNumber); ?></h3>
          <br>
        <h3>Registratin No: <?php echo e($student->rgdNumber); ?></h3>
          <br>
        <h3>Certificate No: <?php echo e($student->certificateNo); ?></h3>
        <br>
        <h3>Student Name: <?php echo e($student->name); ?></h3>
        <br>
        <h3>Father's Name : <?php echo e($student->fname); ?></h3>
        <br>
        <h3>Mother's Name : <?php echo e($student->mname); ?></h3>
        <br>
        <h3>Course Name : <?php echo e($student->course); ?></h3>
        <br>
        <h3>Center Name : <?php echo e($student->centerId); ?></h3>
        <br>
        <h3>Duration :</h3>
        <h3>From : <?php echo e($student->startDate); ?> to :<?php echo e($student->endDate); ?></h3>
        <br>
        <h3>Grade : <?php echo e($student->grade); ?></h3>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <hr>
      <table>
        <tr>
          <th>Subject Name</th>
          <th>Maximum Marks</th>
          <th>Secured Marks</th>
      </tr>
      <?php $__currentLoopData = $studentmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
          <td><?php echo e($studentmark->subjectName); ?></td>
          <td><?php echo e($studentmark->totalMark); ?></td>
          <td><?php echo e($studentmark->securedMark); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $studentmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studenttotalmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>Total</td><td><?php echo e($studenttotalmark->totalMark); ?></td><td><?php echo e($studenttotalmark->securedMark); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
      </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Student/markSheetCertificate.blade.php ENDPATH**/ ?>