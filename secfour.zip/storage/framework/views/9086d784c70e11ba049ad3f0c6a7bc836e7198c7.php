<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">


        <!--Styles -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Student/provisionalCertificate.css')); ?>" />

    </head>
    <body>
      <h2>Provisional Certificate</h2><hr>
      <div class="pCertificate">
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="detdiv">
        <h3 class="details">Roll No: </h3><h3 class="ddetails"><?php echo e($student->rollNumber); ?></h3></div>
          <br>
          <div class="detdiv">
        <h3 class="details">Registration No: </h3><h3 class="ddetails"><?php echo e($student->rgdNumber); ?></h3></div>
          <br>
          <div class="detdiv">
        <h3 class="details">Certificate No: </h3><h3 class="ddetails"><?php echo e($student->certificateNo); ?></h3></div>
        <br>
        <div class="detdiv">
        <h3 class="details">Student Name: </h3><h3 class="ddetails"><?php echo e($student->name); ?></h3></div>
        <br>
        <div class="detdiv">
        <h3 class="details">Father's Name : </h3><h3 class="ddetails"><?php echo e($student->fname); ?></h3></div>
        <br>
        <div class="detdiv">
        <h3 class="details">Mother's Name : </h3><h3 class="ddetails"><?php echo e($student->mname); ?></h3></div>
        <br>
        <div class="detdiv">
        <h3 class="details">Course Name : </h3><h3 class="ddetails"><?php echo e($student->course); ?></h3></div>
        <br>
        <div class="detdiv">
        <h3 class="details">Center ID : </h3><h3 class="ddetails"><?php echo e($student->centerId); ?></h3></div>
        <br>
        <div class="detdiv">
        <h3 class="details">Duration :</h3><h3 class="ddetails"> <?php echo e($student->startDate); ?> - <br><?php echo e($student->endDate); ?></h3></div>
        <br>
        <div class="detdiv">
        <h3 class="details">Grade : </h3><h3 class="ddetails"><?php echo e($student->grade); ?></h3></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="signature">
      <div class="studentSignature"><img src="#" alt="StudentSignature"/><br><h3>Student Signature</h3></div>
      <div class="principalSignature"><img src="#" alt="Principal'sSignature"/><br><h3>Principal's Signature</h3></div>
    </div>
      </div>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="certDesc">
      <p><h4>This is to certify that Mr./Mrs.<?php echo e($student->name); ?> has completed the course <?php echo e($student->course); ?> and attained the grade - <?php echo e($student->grade); ?> after attending class for the same at our institution during the period <?php echo e($student->startDate); ?> to <?php echo e($student->endDate); ?>.We wish him the best for his future.</h4></p>
    </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMPLL\resources\views/Student/provisionalCertificate.blade.php ENDPATH**/ ?>