<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Admin/crudBranch.css')); ?>" />
    </head>
    <body>
      <div class="first" id="upTop">
        <h3><a href="logout" id="fl">Logout</a></h3>
        <h3><a href="/dashboard" id="fl">Go to dashboard</a></h3>
        <h3><a href="#addbranch" id="fl">Add</a></h3>
        <h3><a href="#suspendbranch" id="fl">Suspend</a></h3>
        <h3><a href="#reactivatebranch" id="fl">Reactivate</a></h3>
        <h3><a href="#deletebranch" id="fl">Delete</a></h3></div>
        <?php if($errors->any()): ?>
            <?php echo implode('', $errors->all('<div>:message</div>')); ?>

        <?php endif; ?>
    <div class="addBranch">
        <div class="addNBranch">
        <h3>Newly applied branches</h3>
      <?php $__currentLoopData = $branchDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branchdet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table>
          <tr><th><?php echo e(Form::open(array('route' => 'addBranch','method'=>'post'))); ?></th></tr>
          <tr><?php echo e(Form::token()); ?>

            <td><?php echo e(Form::label('owner name', 'Branch name :')); ?></td><td><?php echo e(Form::text('branchName',$branchdet->branchName)); ?></td></tr><br>
            <tr>
            <td><?php echo e(Form::label('owner name', 'Branch head name :')); ?></td><td><?php echo e(Form::text('branchheadName',$branchdet->name)); ?><?php echo e(Form::hidden('id',$branchdet->id)); ?></td></tr><br>
            <tr>
            <td>  <?php echo e(Form::label('cnumber', 'Contact Number :')); ?></td><td><?php echo e(Form::number('cnumber',$branchdet->cnumber)); ?></td></tr><br>
            <tr>
            <td><?php echo e(Form::label('email', 'Branch Email Id :')); ?></td><td><?php echo e(Form::email('branchemail',$branchdet->mailId)); ?></td></tr><br>
            <tr>
            <td>  <?php echo e(Form::label('branchId', 'BranchId :')); ?></td><td><?php echo e(Form::number('branchId',$branchdet->branchId)); ?></td></tr><br>
            <tr>
            <td><?php echo e(Form::label('branchAddress', 'Branch Address :')); ?></td><td><?php echo e(Form::text('branchAddress',$branchdet->address)); ?></td></tr><br>
          </tr></table><br><?php echo e(Form::submit('Add')); ?>

            <?php echo e(Form::close()); ?>

            <div>
            <?php echo e(Form::open(array('method' => 'put','route' => 'provideAdminImage','files' => 'true','enctype'=>'multipart/form-data'))); ?>

            <?php echo e(Form::token()); ?>

              <?php echo e(Form::file('file')); ?><?php echo e(Form::hidden('branchId',$branchdet->branchId)); ?>

              <?php echo e(Form::submit('Upload')); ?>

            <?php echo e(Form::close()); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="addNewBranch">
          <div>
            <h3>Add branch directly</h3>
          <table>
            <tr><th><?php echo e(Form::open(array('route' => 'addBranch','method'=>'post'))); ?></th></tr>
            <tr><?php echo e(Form::token()); ?>

              <td><?php echo e(Form::label('owner name', 'Branch name :')); ?></td><td><?php echo e(Form::text('branchName')); ?></td></tr><br>
              <tr>
              <td><?php echo e(Form::label('owner name', 'Branch head name :')); ?></td><td><?php echo e(Form::text('branchheadName')); ?><?php echo e(Form::hidden('id')); ?></td></tr><br>
              <tr>
              <td>  <?php echo e(Form::label('cnumber', 'Contact Number :')); ?></td><td><?php echo e(Form::number('cnumber')); ?></td></tr><br>
              <tr>
              <td><?php echo e(Form::label('email', 'Branch Email Id :')); ?></td><td><?php echo e(Form::email('branchemail')); ?></td></tr><br>
              <tr>
              <td>  <?php echo e(Form::label('branchId', 'BranchId :')); ?></td><td><?php echo e(Form::number('branchId')); ?></td></tr><br>
              <tr>
              <td><?php echo e(Form::label('branchAddress', 'Branch Address :')); ?></td><td><?php echo e(Form::text('branchAddress')); ?></td></tr><br>
            </tr></table><br><?php echo e(Form::submit('Add')); ?>

              <?php echo e(Form::close()); ?>

            </div>
              <div>
              <?php echo e(Form::open(array('method' => 'put','route' => 'provideAdminImage','files' => 'true','enctype'=>'multipart/form-data'))); ?>

              <?php echo e(Form::token()); ?>

                <?php echo e(Form::file('file')); ?><?php echo e(Form::hidden('branchId')); ?>

                <?php echo e(Form::submit('Upload')); ?>

              <?php echo e(Form::close()); ?></div>
            </div>
           </div>
      <hr>
    <hr>
    <div class="branchActions">
    <div id="suspendbranch">
      <h2>Suspend Branch</h2>
      <?php echo e(Form::open(array('route' => 'suspendBranch'))); ?><?php echo e(Form::token()); ?>

      <?php echo e(Form::select('branchId', $activeBranch)); ?>

      <?php echo e(Form::submit('Suspend')); ?>

    <?php echo e(Form::close()); ?>

    <h3><a href="#upTop">Go Up</a></h3>
    </div>
    <div class="reactivateBranch" id="reactivatebranch">
      <h2>Reactivate Branch</h2>
      <?php echo e(Form::open(array('route' => 'reactivateBranch'))); ?><?php echo e(Form::token()); ?>

      <?php echo e(Form::select('branchId', $reactivateBranch)); ?>

      <?php echo e(Form::submit('Reactivate')); ?>

    <?php echo e(Form::close()); ?>


    </div>
    <div class="deleteBranch" id="deletebranch">
      <h2>Delete Branch</h2>
      <?php echo e(Form::open(array('route' => 'deleteBranch'))); ?><?php echo e(Form::token()); ?>

      <?php echo e(Form::select('branchId', $branch)); ?>

      <?php echo e(Form::submit('Delete')); ?>

    <?php echo e(Form::close()); ?>

    </div>
    </div>
    </body>
</html>
<?php /**PATH /home/u548630683/domains/jsttryngnout.tech/SMP/resources/views/Admin/crudBranch.blade.php ENDPATH**/ ?>