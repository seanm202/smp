<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->



    </head>
    <body>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="dashboard">Go to dashboard</a></h3>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
      <h2>Student Report</h2>
      <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <table>
        <tr>
          <th>Name of the student </th>
          <th><?php echo e($student->name); ?></th>
        </tr>
        <tr>
          <td>Father's Name </td>
            <td><?php echo e($student->fname); ?></td>
        </tr>
        <tr>
          <td>Mother's Name </td>
            <td><?php echo e($student->mname); ?></td>
        </tr>
        <tr>
          <td>Center Address</td>
            <td><?php echo e($student->centerAddress); ?></td>
        </tr>
        <tr>
          <td>Center Id</td>
            <td><?php echo e($student->centerId); ?></td>
        </tr>
        <tr>
          <td>Student Address</td>
            <td><?php echo e($student->Address); ?></td>
        </tr>
        <tr>
          <td>Course Name</td>
            <td><?php echo e($student->course); ?></td>
        </tr>
        <tr>
          <td>Registration Number</td>
            <td><?php echo e($student->rgdNumber); ?></td>
        </tr>
        <tr>
          <td>Roll Number</td>
            <td><?php echo e($student->rollNumber); ?></td>
        </tr>
        <tr>
          <td>Course Status</td>
            <td><?php echo e($student->status); ?></td>
        </tr>
        <tr>
          <td><p style="background-color:blue;width=100%;"></p></td>
            <td><p style="background-color:blue;width=100%;"></p></td>
        </tr>
      </table>
      <hr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMPLL\resources\views/Admin/Report.blade.php ENDPATH**/ ?>