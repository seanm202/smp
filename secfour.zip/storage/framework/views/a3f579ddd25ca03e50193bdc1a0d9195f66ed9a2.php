<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Branch/examManagement.css')); ?>" />
        <!-- Styles -->

        <style>
        #students {
          font-family: Arial, Helvetica, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }

        #students td, #students th {
          border: 1px solid #ddd;
          padding: 8px;
        }

        #students tr:nth-child(even){background-color: #f2f2f2;}

        #students tr:hover {background-color: #ddd;}

        #students th {
          padding-top: 12px;
          padding-bottom: 12px;
          text-align: left;
          background-color: #04AA6D;
          color: white;
        }

        .buttonCalc {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

.buttonCourse{
background-color: #4CAF50; /* Green */
border: none;
color: white;
padding: 15px 32px;
text-align: center;
text-decoration: none;
display: inline-block;
font-size: 16px;
}

        .buttonImage {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}


        .buttonAdd {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}


        .buttonStudent {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

.buttonFile{
background-color: #4CAF50; /* Green */
border: none;
color: white;
padding: 15px 32px;
text-align: center;
text-decoration: none;
display: inline-block;
font-size: 16px;
}
        </style>


    </head>
    <body>
      <h3><a href="dashboard">Go back to dashboard</a></h3>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
      <h2>Exam Management</h2>
      <h3>Choose the Student :</h3>
      <table id="students">
        <tr>
        <th>Roll Number</th>
        <th>Registration Number</th>
        <th>Student Name</th>
        <th>Select</th>
      </tr>
      <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e(Form::open(array('route' => 'getCourses'))); ?>

      <tr>
        <td><?php echo e($student->rollNumber); ?></td>
        <td><?php echo e($student->rgdNumber); ?></td>
        <td><?php echo e($student->name); ?></td>
      <td><?php echo e(Form::hidden('studentId',$student->studentId)); ?>

      <?php echo e(Form::submit('Select',array('class' =>'buttonStudent'))); ?>

      <?php echo e(Form::close()); ?></td>
    </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>

        <?php if(isset($courses)): ?>
      <h3>Choose the course :</h3>
      <div class="selectCourse">
      <?php echo e(Form::open(array('route' => 'getSubjects'))); ?>

      <?php echo e(Form::select('courseId',$courses)); ?>

      <?php echo e(Form::submit('Submit',array('class' =>'buttonCourse'))); ?>

      <?php echo e(Form::close()); ?></div>
      <?php endif; ?>

      <?php if(isset($subjects)): ?>
        <hr>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
        <table id="students">
        <tr>
            <th>Subject Name</th>
            <th>Total Mark</th>
            <th>Secured Mark</th>
            <th>Update</th>
         </tr>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
         <?php echo e(Form::open(array('route' => 'addSubjectMark'))); ?>

            <td><?php echo e($subject->subjectName); ?></td>
            <td><?php echo e(Form::label($subject->totalMark)); ?></td>
            <td><?php echo e(Form::number('subjectSecuredMark')); ?></td>
            <?php echo e(Form::hidden('subjectId',$subject->subjectId)); ?>

            <?php echo e(Form::hidden('studentId',$studentId)); ?>

            <?php echo e(Form::hidden('courseId',$courseID)); ?>

            <td><?php echo e(Form::submit('Submit',array('class' =>'buttonAdd'))); ?></td>
          <?php echo e(Form::close()); ?>

        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
<!-- Image Upload-->

    <div class="imageUpload">
        <?php echo e(Form::open(array('action' => 'ExamController@addStudentPhoto','method' => 'put','files' => 'true','enctype'=>'multipart/form-data'))); ?>

      <?php echo e(Form::token()); ?>

      <?php echo e(Form::hidden('studentId',$studentId)); ?>

      <?php echo e(Form::label('image', 'Add Image')); ?><br>
      <?php echo e(Form::file('image',array('class' =>'buttonFile'))); ?><br><br>
      <?php echo e(Form::submit('Upload',array('class' =>'buttonImage'))); ?><br>
            <?php echo e(Form::close()); ?>

            </div>
<!-- Image Upload-->
        <div class="calculateTotal">
          <h3>To calculate or update total marks for this course, press the submit button below</h3>
      <p><?php echo e(Form::open(array('route' => 'calcCourseTotal'))); ?>

          <?php echo e(Form::hidden('courseId',$courseID)); ?>

          <?php echo e(Form::hidden('studentId',$studentId)); ?>

          <?php echo e(Form::submit('Calculate',array('class' =>'buttonCalc'))); ?>

        <?php echo e(Form::close()); ?></p>
    <?php endif; ?>
  </div>
    </body>
</html>
<?php /**PATH /home/u548630683/domains/jsttryngnout.tech/SMP/resources/views/Branch/examManagement.blade.php ENDPATH**/ ?>