<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u548630683/domains/jsttryngnout.tech/SMP/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>