<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Branch/studentAdmission.css')); ?>" />



    </head>
    <body>
      <h3><a href="dashboard">Go back to dashboard</a></h3>
        <h3><a href="logout">Logout</a></h3>

        <?php if($errors->any()): ?>
            <?php echo implode('', $errors->all('<div>:message</div>')); ?>

        <?php endif; ?>
    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
        <div class="validationErrorDisplay">

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

        </div>

        <div class="studAdmission"
      <h2>Student Admission</h2>
      <h3>Student Profile</h3>
      <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="profileForm">
        <?php echo e(Form::open(array('route' => 'addStudentDetails'))); ?>

        <?php echo e(Form::label('id', 'Student Id:')); ?>

        <?php echo e(Form::text('studentid',$student->studentId)); ?><br><br>
        <?php echo e(Form::label('email', 'Email:')); ?>

        <?php echo e(Form::text('email',$student->emailId)); ?><br><br>
        <?php echo e(Form::label('name', 'Name:')); ?>

        <?php echo e(Form::text('name',$student->name)); ?><br><br>
        <?php echo e(Form::label('fname', 'Father Name:')); ?>

        <?php echo e(Form::text('fname',$student->fname)); ?><br><br>
        <?php echo e(Form::label('mname', 'Mother Name:')); ?>

        <?php echo e(Form::text('mname',$student->mname)); ?><br><br>
        <?php echo e(Form::label('Address', 'Address:')); ?>

        <?php echo e(Form::text('address',$student->Address)); ?><br><br>
        <?php echo e(Form::label('contact', 'Contact Number:')); ?>

        <?php echo e(Form::number('contactnumber',$student->cnumber)); ?><br><br>
        <?php echo e(Form::label('course', 'Course:')); ?>

        <?php echo e(Form::select('courseId',$courses)); ?><br><br>
        <hr>
        <table id="studentQualification">
          <tr>
          <th>Sl.No</th>
          <th>Qualification</th>
          <th>Board/University</th>
          <th>Full Mark</th>
          <th>Secured Mark</th>
        </tr>
        <!-- 10th marks-->
            <tr>
            <td>1</td>
            <td>10th</td>
            <td><?php echo e(Form::text('tenthboard')); ?></td>
            <td><?php echo e(Form::number('tenthtotalmark')); ?></td>
            <td><?php echo e(Form::number('tenthsecuredmark')); ?></td>
            </tr>
            <!-- 12th marks-->
            <tr>
            <td>2</td>
            <td>12th</td>
            <td><?php echo e(Form::text('twelfththboard')); ?></td>
            <td><?php echo e(Form::number('twelfththtotalmark')); ?></td>
            <td><?php echo e(Form::number('twelfthsecuredmark')); ?></td>
            </tr>
            <!-- 13th marks-->
            <tr>
            <td>3</td>
            <td>13th</td>
            <td><?php echo e(Form::text('thirteenthboard')); ?></td>
            <td><?php echo e(Form::number('thirteenththtotalmark')); ?></td>
            <td><?php echo e(Form::number('thirteenthsecuredmark')); ?></td>
            </tr>
            <!-- Other marks-->
            <tr>
            <td>4</td>
            <td>Other</td>
            <td><?php echo e(Form::text('otherboard')); ?></td>
            <td><?php echo e(Form::number('othertotalmark')); ?></td>
            <td><?php echo e(Form::number('othersecuredmark')); ?></td>
            </tr>
        </table>
        <hr>
        <?php echo e(Form::submit('Submit')); ?>

      <?php echo e(Form::close()); ?>

    </div>
    <hr>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
    </body>
</html>
<?php /**PATH /home/u548630683/domains/jsttryngnout.tech/SMP/resources/views/Branch/studentAdmission.blade.php ENDPATH**/ ?>