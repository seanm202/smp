<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">


    </head>
    <body>
    <div>
      <h2>Add Branch</h2>
      <?php echo e(Form::open(array('method'=>'post','route' => 'addBranch'))); ?>

      <?php echo e(Form::label('owner name', 'Branch head name :')); ?>

      <?php echo e(Form::text('branchname')); ?><br><br>
      <?php echo e(Form::label('cnumber', 'Contact Number :')); ?>

      <?php echo e(Form::number('cnumber')); ?><br><br>
      <?php echo e(Form::label('email', 'Branch Email Id :')); ?>

      <?php echo e(Form::email('branchemail')); ?><br><br>
      <?php echo e(Form::label('branchId', 'BranchId :')); ?>

      <?php echo e(Form::text('branchId')); ?><br><br>
      <?php echo e(Form::label('branchAddress', 'Branch Address :')); ?>

      <?php echo e(Form::text('branchAddress')); ?><br><br>
      <?php echo e(Form::submit('Add')); ?><br><br>
    <?php echo e(Form::close()); ?>

    </div>
    <hr>
    <div>
      <h2>Suspend Branch</h2>
      <?php echo e(Form::open(array('route' => 'suspendBranch'))); ?>

      <?php echo e(Form::select('id', $branch)); ?>

      <?php echo e(Form::submit('Suspend')); ?>

    <?php echo e(Form::close()); ?>

    </div>
    <hr>
    <div class="reactivateBranch">
      <h2>Reactivate Branch</h2>
      <?php echo e(Form::open(array('route' => 'reactivateBranch'))); ?>

      <?php echo e(Form::select('id', $branch)); ?>

      <?php echo e(Form::submit('Reactivate')); ?>

    <?php echo e(Form::close()); ?>

    </div>
    <hr>
    <div class="deleteBranch">
      <h2>Delete Branch</h2>
      <?php echo e(Form::open(array('route' => 'deleteBranch'))); ?>

      <?php echo e(Form::select('id', $branch)); ?>

      <?php echo e(Form::submit('Delete')); ?>

    <?php echo e(Form::close()); ?>

    </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SMP\resources\views/Admin/crudBranch.blade.php ENDPATH**/ ?>