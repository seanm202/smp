<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Admin/crudCourse.css')); ?>" />
    </head>
    <body>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="dashboard">Go to dashboard</a></h3>
        <?php if($errors->any()): ?>
            <?php echo implode('', $errors->all('<div>:message</div>')); ?>

        <?php endif; ?>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
      <h2 style="padding-left:300px;">Create/Read/Edit/Delete Course(s)</h2>
      <div class="subjectCourse">
      <div class="addCourse">
        <h2>Add Course(s)</h2>
        <?php echo e(Form::open(array('route' => 'addCourse','method'=>'post'))); ?>

        <?php echo e(Form::label('courseid', 'Course Id :')); ?>

        <?php echo e(Form::text('courseId')); ?><br><br>
        <?php echo e(Form::label('course', 'Course Name :')); ?>

        <?php echo e(Form::text('courseName')); ?><br><br>
        <?php echo e(Form::label('total mark', 'Total Mark :')); ?>

        <?php echo e(Form::number('totalMark')); ?><br><br>
        <?php echo e(Form::submit('Add')); ?>

      <?php echo e(Form::close()); ?>

      </div>
      <hr>
      <div class="deleteCourse">
        <h2>Delete Course(s)</h2>
        <?php echo e(Form::open(array('route' => 'deleteCourse'))); ?>

        <?php echo e(Form::select('courseId',$courses)); ?>

        <?php echo e(Form::hidden('id')); ?>

        <?php echo e(Form::submit('Delete')); ?>

      <?php echo e(Form::close()); ?>

      </div>
    </div>
<!--
    <hr>
    <div class="updateCourse">
      <h2>Update Course(s)</h2>
      <?php echo e(Form::open(array('route' => 'addCourse','method'=>'post'))); ?>

      <?php echo e(Form::label('courseid', 'Course Id :')); ?>

      <?php echo e(Form::select('courseId',$courses)); ?><br><br>
      <?php echo e(Form::label('total mark', 'Total Mark :')); ?>

      <?php echo e(Form::number('totalMark')); ?><br><br>
      <?php echo e(Form::submit('Update')); ?>

    <?php echo e(Form::close()); ?>

  </div>-->
    </body>
</html>
<?php /**PATH /home/u548630683/domains/jsttryngnout.tech/SMP/resources/views/Admin/crudCourse.blade.php ENDPATH**/ ?>