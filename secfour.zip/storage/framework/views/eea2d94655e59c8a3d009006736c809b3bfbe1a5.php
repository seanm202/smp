<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Admin/crudSubject.css')); ?>" />

    </head>
    <body>
        <h3><a href="logout">Logout</a></h3>
        <h3><a href="dashboard">Go to dashboard</a></h3>

    <div id="app">
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Scripts -->
    <script src="/js/app.js"></script>
      <h2 style="padding-left:300px;">Create/Read/Edit/Delete Subject(s)</h2>
      <div class="subject">
        <div class="addSubject">
          <h2>Add Subject(s)</h2>
          <?php echo e(Form::open(array('route' => 'addSubject'))); ?>

          <?php echo e(Form::label('courseName', 'Course Name :')); ?>

          <?php echo e(Form::select('courseId', $courses)); ?><br><br>
          <?php echo e(Form::label('subjectname', 'Subject Name :')); ?>

          <?php echo e(Form::text('subjectName')); ?><br><br>
          <!--
          <?php echo e(Form::label('subjectId', 'Subject Id :')); ?>

          <?php echo e(Form::text('subjectId')); ?><br><br> -->
          <?php echo e(Form::label('totalMark', 'TotalMark :')); ?>

          <?php echo e(Form::number('totalMark')); ?><br><br>
          <?php echo e(Form::submit('Add')); ?>

        <?php echo e(Form::close()); ?>

        </div>
        <hr>
        <div class="deleteSubject">
          <h2>Delete Subject(s)</h2>
          <?php echo e(Form::open(array('route' => 'deleteSubject'))); ?>

          <?php echo e(Form::label('courseName', 'Course Name :')); ?>

          <?php echo e(Form::select('courseId', $courses)); ?><br><br>
          <?php echo e(Form::label('subjectName', 'Subject Name :')); ?>

          <?php echo e(Form::select('subjectId',$subjects)); ?>

          <?php echo e(Form::hidden('id')); ?>

          <?php echo e(Form::submit('Delete')); ?>

        <?php echo e(Form::close()); ?>

        </div>
        </div>
    </body>
</html>
<?php /**PATH /home/u548630683/domains/jsttryngnout.tech/SMP/resources/views/Admin/crudSubject.blade.php ENDPATH**/ ?>